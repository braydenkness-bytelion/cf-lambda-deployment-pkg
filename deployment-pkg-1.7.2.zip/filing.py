class Filing:
    def __init__(self, name_of_issuer, issuer_website, link, jurisdiction,
        offering_amount, no_of_security_offered, price, company_name):

        self.name_of_issuer = name_of_issuer
        self.issuer_website = issuer_website
        self.link = link
        self.jurisdiction = jurisdiction
        self.offering_amount = offering_amount
        self.no_of_security_offered = no_of_security_offered
        self.price = price
        self.company_name = company_name
